﻿namespace BlazingPizza.ComponentsLibrary.Map
{
    public class Point
    {
        public double X { get; set; }

        public double Y { get; set; }
    }
}
